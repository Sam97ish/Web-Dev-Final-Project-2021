import { app } from "./app.js";

app.listen({ port: 7777 });
console.log("# SERVER IS RUNNING LOCALLY AT PORT 7777");