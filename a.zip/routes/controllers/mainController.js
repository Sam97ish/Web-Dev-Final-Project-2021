const showMain = ({ render }) => {
  render("./partials/main.eta");
};

export { showMain };
